

import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

import com.ibra.objets.tuyau;
import com.ibra.personnages.FlappyBird;

public class Scene extends JPanel{
	
	private ImageIcon icoBandeFond;
	private Image imgBandeFond;
	
	public tuyau tuyauHaut1;
	public tuyau tuyauBas1;
	public tuyau tuyauHaut2;
	public tuyau tuyauBas2;
	public tuyau tuyauHaut3;
	public tuyau tuyauBas3;
	
	public FlappyBird flappyBird;
	
	private final int LARGEUR_BANDE_FOND = 140;
	private final int DISTANCE_TUYAUX = 250;
	private final int ECART_TUYAUX = 120;
	
	
	public int xFond;
	private int xTuyaux;
	
	private Random hasard;
	
	
	public Scene() {
		
		super();
		this.icoBandeFond = new ImageIcon(getClass().getResource("images/bandeFondEcran.png"));
		this.imgBandeFond = this.icoBandeFond.getImage();
		
		this.xFond = 0;
		this.xTuyaux = 100;
		
		this.tuyauHaut1 = new tuyau(this.xTuyaux, -150,"/images/tuyauHaut.png");
		this.tuyauBas1 = new tuyau(this.xTuyaux, 250, "/images/tuyauBas.png");
		this.tuyauHaut2 = new tuyau(this.xTuyaux + this.tuyauBas1.getLargeur() + this.DISTANCE_TUYAUX, -100,"/images/tuyauHaut.png");
		this.tuyauBas2 = new tuyau(this.xTuyaux + this.tuyauHaut1.getLargeur() + this.DISTANCE_TUYAUX, 300, "/images/tuyauBas.png");
		this.tuyauHaut3 = new tuyau(this.xTuyaux + this.tuyauBas1.getLargeur() + this.DISTANCE_TUYAUX * 2, -120,"/images/tuyauHaut.png");
		this.tuyauBas3 = new tuyau(this.xTuyaux + this.tuyauHaut1.getLargeur() + this.DISTANCE_TUYAUX, 280, "/images/tuyauBas.png");
		
		this.flappyBird = new FlappyBird(100, 150,"/images/oiseau1.png");
		
		hasard = new Random();
		
		this.setFocusable(true);
		this.requestFocusInWindow();
		this.addKeyListener(new Clavier()); 

		Thread chronoEcran = new Thread(new Chrono());
		chronoEcran.start();		
		
	}
	
	//METHODES
	
	private void deplacementFond(Graphics g) {
		if (this.xFond == -this.LARGEUR_BANDE_FOND) {
			this.xFond = 0;
		}
		g.drawImage(this.imgBandeFond, this.xFond, 0, null);
		g.drawImage(this.imgBandeFond, this.xFond + this.LARGEUR_BANDE_FOND, 0, null);
		g.drawImage(this.imgBandeFond, this.xFond + this.LARGEUR_BANDE_FOND * 2, 0, null);
		g.drawImage(this.imgBandeFond, this.xFond + this.LARGEUR_BANDE_FOND * 3, 0, null);
	}
	public void deplacementTuyaux(Graphics g) {
		// tuyau1
	    this.tuyauHaut1.setX(this.tuyauHaut1.getX() - 1);
		this.tuyauBas1.setX(this.tuyauHaut1.getX());
		
		if(this.tuyauHaut1.getX() == -100){
	    	this.tuyauHaut1.setX(this.tuyauHaut3.getX() + this.DISTANCE_TUYAUX);
	    	this.tuyauHaut1.setY(-100 - 10 * this.hasard.nextInt(18));
	    	this.tuyauBas1.setY(this.tuyauHaut1.getY() + this.tuyauHaut1.getHauteur() + this.ECART_TUYAUX);
	    }		
		g.drawImage(this.tuyauHaut1.getImgTuyau(), this.tuyauHaut1.getX(), this.tuyauHaut1.getY(), null);
		g.drawImage(this.tuyauBas1.getImgTuyau(), this.tuyauBas1.getX(), this.tuyauBas1.getY(), null);
		
		// tuyau2
		this.tuyauHaut2.setX(this.tuyauHaut2.getX() - 1);
		this.tuyauBas2.setX(this.tuyauHaut2.getX());
		
		if(this.tuyauHaut2.getX() == -100){
			this.tuyauHaut2.setX(this.tuyauHaut1.getX() + this.DISTANCE_TUYAUX);
			this.tuyauHaut2.setY(-100 - 10 * this.hasard.nextInt(18));
	    	this.tuyauBas2.setY(this.tuyauHaut2.getY() + this.tuyauHaut2.getHauteur() + this.ECART_TUYAUX);
		}		
		g.drawImage(this.tuyauHaut2.getImgTuyau(), this.tuyauHaut2.getX(), this.tuyauHaut2.getY(), null);
		g.drawImage(this.tuyauBas2.getImgTuyau(), this.tuyauBas2.getX(), this.tuyauBas2.getY(), null);
		
		// tuyau3
		this.tuyauHaut3.setX(this.tuyauHaut3.getX() - 1);
		this.tuyauBas3.setX(this.tuyauHaut3.getX());
		
		if(this.tuyauHaut3.getX() == -100){
			this.tuyauHaut3.setX(this.tuyauHaut2.getX() + this.DISTANCE_TUYAUX);
			this.tuyauHaut3.setY(-100 - 10 * this.hasard.nextInt(18));
	    	this.tuyauBas3.setY(this.tuyauHaut3.getY() + this.tuyauHaut3.getHauteur() + this.ECART_TUYAUX);
		}		
		g.drawImage(this.tuyauHaut3.getImgTuyau(), this.tuyauHaut3.getX(), this.tuyauHaut3.getY(), null);
		g.drawImage(this.tuyauBas3.getImgTuyau(), this.tuyauBas3.getX(), this.tuyauBas3.getY(), null);
	}
	public void paintComponent(Graphics g) {
		this.deplacementFond(g);
		this.deplacementTuyaux(g);
		this.flappyBird.setY(this.flappyBird.getY() + 1);
		g.drawImage(this.flappyBird.getImgOiseau(), this.flappyBird.getX(), this.flappyBird.getY(), null);
	}
}
